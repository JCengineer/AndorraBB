<div id="infoFriends">
	<h3 id="ovH7" class="infoTab">Friends, local services and deals</h3>
	<p>
		<h3> Transport services: </h3>
	 	<a id="aircoach" href="//aircoach.ie">AirCoach</a><br>
	 	<a id="dublinBus" href="//dublinbus.ie"> Dublin bus</a><br>
	 	<a id="globalTaxis" href="//globalTaxis.ie"> Global Taxi company</a><br>
	 	<a id="irishRail" href="//irishrail.ie"> Dart rail service</a><br>
	 	<br>
	 	<h3> Event venues: </h3>
	 	<a id="RDS" href="//RDS.ie"> Royal Dublin Society (RDS)</a><br>
	 	<a id="aviva" href="//avivastadium.ie"> Aviva Stadium (Formerly Lansdowne Road stadium)</a><br>
	 	<a id="BGET" href="//bordgaisenergytheatre.ie"> Bord G&aacute;is Energy Theatre (Formerly Grand Canal Theatre)</a><br>
	 	<a id="CCD" href="//theccd.ie"> Convention Centre Dublin ( CCD )</a><br>
	 	<br>

	 	<h3> Local Restaurants </h3><br>

		<a href="//rolysbistro.ie">Roly's Bistro</a><br>
		7 Ballsbridge Terrace<br>
		Dublin 4<br>
		(01) 668 2611<br>
		<br>
		Al Boshetto<br>
		2 Merrion Rd<br>
		Dublin 4<br>
		(01) 667 3784<br>
		<br>
		Bianconi’s Restaurant<br>
		232 Merrion Road<br>
		Ballsbridge<br>
		Dublin 4<br>
		Ph. (01) 2196033<br>
		<br>
		<a href="//www.thelobsterpot.ie">Lobster Pot</a><br>
		9 Ballsbridge Terrace<br>
		Ballsbridge<br>
		Dublin 4<br>
		(01) 668 0025<br>
		<br>
		Paddy Cullen's Pub<br>
		14 Merrion Rd<br>
		Dublin<br>
		<br>
		<a href="//www.bella-cuba.com">Bella Cuba Restaurant</a><br>
		11 Ballsbridge Terrace<br>
		Dublin<br>
		(01) 660 5539<br>
		<br>
		<a href="//www.baanthai-restaurant.com">Baan Thai Ballsbridge</a><br>
		16 Merrion Rd<br>
		Dublin<br>
		(01) 660 8833<br>
		<br>
		<a href="//www.fourseasons.com"> Seasons Restaurant </a><br>
		4 Simmonscourt Rd<br>
		Dublin<br>
		(01) 665 4000<br>
		<br>
		<a href="//www.themerrioninn.com"> The Merrion Inn </a><br>
		188 Merrion Road<br>
		Ballsbridge<br>
		Dublin 4<br>
		Ph. (01)2693816<br>
		<br>
	</p>
</div>