<div id="infoNews">
	<h3 id="ovH6" class="infoTab">News, events and blog</h3>
	<p>
		Due to the amenities in our location, we are always busy with local events.
	<br> Keep an eye here for our updates on the popular events in the area.
	</p><br>
</div>