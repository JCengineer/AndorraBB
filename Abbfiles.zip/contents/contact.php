<div id="infoContact">
	<h3 id="ovH8" class="infoTab">Contact us by email, phone or form</h3>
	<p>
		Use our contact form, email or phone number to contact us at Andorra today. <br>
		<div id="contactUs2" align="center">
			<!-- Do not change the code! -->
			<a id="foxyform_embed_link_516694" href="http://www.foxyform.com/">foxyform</a>
			<script type="text/javascript">
			(function(d, t){
			   var g = d.createElement(t),
			       s = d.getElementsByTagName(t)[0];
			   g.src = "http://www.foxyform.com/js.php?id=516694&sec_hash=648e738d1cc&width=350px";
			   s.parentNode.insertBefore(g, s);
			}(document, "script"));
			</script>
			<!-- Do not change the code! -->
		</div>
	<br>
	Nuala and Fionán can be contacted by phone or email:<br>
	Telephone: (Ire +353) 01 6689666<br>
	Email: &#x65;&#x6e;&#x71;&#x75;&#x69;&#x72;&#x69;&#x65;&#x73;&#x40;&#x61;&#x6e;&#x64;&#x6f;&#x72;&#x72;&#x61;&#x62;&#x62;&#x2e;&#x63;&#x6f;&#x6d;<br>
	We are happy to answer any questions and take bookings via email and phone.
	We are generally available from 8am to 11pm (GMT +00:00) for calls.
	</p><br>
</div>