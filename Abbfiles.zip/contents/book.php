<div id="infoBook" class="infoTab">
	<h3 id="ovH2">Book with us now</h3>
	<p>
		You can use our booking form on booking.com to secure your accommodation at Andorra now. <br>
		<!-- BOOKING.COM BOOK NOW BUTTON-->
		<a href="http://www.booking.com/hotel/ie/andorra-bed-and-breakfast.html?aid=330843;lang=en" target="_blank">
		<img src="http://aff.bstatic.com/images/affiliate/330843/booknow_en.gif" style="border: 0;"/></a>
		<br>
		Enter your dates required below and click "check availability" to get there:<br>
		<div id="bookingDotComForm">
			<!-- BOOKING.COM CHECK AVAILABILITY FORM-->
			<script type="text/javascript" src="http://www.booking.com/general.html?tmpl=bookit;aid=330843;lang=en;hotel_id=252595;cc1=ie;hotel_page=andorra-bed-and-breakfast"></script>
		</div>
		<br>
		You can also contact us by email, phone or contact form below. 
		We will be more than happy to answer any queries and take your booking this way.
		Call us on (Ire +353) 01 6689666 or email us at &#x65;&#x6e;&#x71;&#x75;&#x69;&#x72;&#x69;&#x65;&#x73;&#x40;&#x61;&#x6e;&#x64;&#x6f;&#x72;&#x72;&#x61;&#x62;&#x62;&#x2e;&#x63;&#x6f;&#x6d;
		<br><br>
		<div id="contactUs1" align="center">
			<!-- Do not change the code! -->
			<a id="foxyform_embed_link_510032" href="http://www.foxyform.com/">foxyform</a>
			<script type="text/javascript">
			(function(d, t){
			   var g = d.createElement(t),
			       s = d.getElementsByTagName(t)[0];
			   g.src = "http://www.foxyform.com/js.php?id=510032&sec_hash=1d876f64f29&width=350px";
			   s.parentNode.insertBefore(g, s);
			}(document, "script"));
			</script>
			<!-- Do not change the code! -->
		</div>

	</p>
</div>