<div id="headingA">
	<h1> 
		<img id="stars" src="images\star.png" alt="4 Star Andorra B&amp;B"/>
		<img id="stars" src="images\star.png" alt="4 Star Andorra B&amp;B"/>
		<img id="stars" src="images\star.png" alt="4 Star Andorra B&amp;B"/>
		<img id="stars" src="images\star.png" alt="4 Star Andorra B&amp;B"/>
		Andorra <br> Bed &amp; Breakfast </h1>
	<!--h2> Nuala &amp; Fionan Clifford </h2>
	<h3> 94 Merrion Road, Ballsbridge,<br>Dublin 4, Ireland </h3-->
</div>
<div id="headingB">
	<h3>Comfortable and homely guest accommodation</h3>
	<span>Welcome, C&eacute;ad M&iacute;le F&aacute;ilte, Bienvenue, Willkommen, Bienvenido, Benenuto</span>
</div>
<div id="leftMenuBar">
	<button id="aboutUs" class="button" title="About Andorra B&amp;B" onclick="location.href='AboutUs.php';">
		About us</button>
	<button id="bookNow" class="button" title="Book with us now" onclick="location.href='BookNow.php';">
		Book Now</button>
	<button id="rooms" class="button" title="Our guestrooms" onclick="location.href='Rooms.php';">
		Rooms</button>
	<button id="facilities" class="button" title="Our local facilities and amenities" onclick="location.href='ContactUs.php';">
		Amenities</button>
	<button id="location" class="button" title="The location" onclick="location.href='Location.php';">
		Location</button>
	<button id="news" class="button" title="News, events and blog" onclick="location.href='News.php';">
		News</button>
	<button id="friends" class="button" title="Friends, local services and deals" onclick="location.href='Affiliates.php';">
		Friends</button>
	<button id="contactUs" class="button" title="Contact us by email, phone or form" onclick="location.href='ContactUs.php';">
		Contact Us</button>
</div>