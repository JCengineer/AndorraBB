<span id="thankYouText" title="We hope to see you soon."> 
	<a href="//www.andorrabb.com"> 
		Thank you for visiting AndorraBB
	</a>
</span>
<span id="infoText" title="We hope to see you soon.">
		94 Merrion Road, Ballsbridge, Dublin 4<br>
		+353 1 6689666 / &#x65;&#x6e;&#x71;&#x75;&#x69;&#x72;&#x69;&#x65;&#x73;&#x40;&#x61;&#x6e;&#x64;&#x6f;&#x72;&#x72;&#x61;&#x62;&#x62;&#x2e;&#x63;&#x6f;&#x6d;
</span>
<!--div id="bookingButton"-->
	<!-- BOOKING.COM BOOK NOW BUTTON-->
	<!--a href="http://www.booking.com/hotel/ie/andorra-bed-and-breakfast.html?aid=330843;lang=en" target="_blank">
		<img src="http://aff.bstatic.com/images/affiliate/330843/booknow_en.gif" style="border: 0;" />
	</a>
</div-->
<button id="bookButton" class="button" onclick="location.href='http://www.booking.com/hotel/ie/andorra-bed-and-breakfast.html?aid=330843;lang=en';" title="We hope to see you soon.">Book Now</button>
<!--span id="expandFooterIcon" class="ui-icon ui-icon-carat-1-n"></span-->
